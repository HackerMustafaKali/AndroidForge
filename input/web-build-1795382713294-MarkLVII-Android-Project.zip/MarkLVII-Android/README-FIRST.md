# MARK LVII Android — personal port

This is a native Android starter port based on the uploaded MARK LVII source. It keeps the dark holographic HUD idea, voice input, Gemini text generation, and Android text-to-speech. The original desktop Python/PyQt6 application cannot be copied directly into Android, so this project recreates the mobile UI and moves the assistant interaction to Android APIs.

## Easiest build
1. Put this folder in a GitHub repository.
2. Open **Actions** → **Build MARK LVII Android APK** → **Run workflow**.
3. Download the artifact `mark-lvii-debug-apk`.
4. Extract `app-debug.apk` and install it on the phone.

## Gemini
On first run tap ⚙ and paste your Gemini API key. The key is stored locally in Android app preferences and is sent directly to Google's API. Do not share the APK after embedding a key (this build does not embed one).

## Important
The upstream project is licensed CC BY-NC 4.0. This personal/non-commercial derivative should retain attribution and the license. Do not use this port commercially without checking the upstream license.
