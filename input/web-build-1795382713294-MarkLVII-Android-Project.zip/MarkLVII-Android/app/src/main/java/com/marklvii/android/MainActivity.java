package com.marklvii.android;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.os.*;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    HudView hud; TextView log; EditText input; Button mic, send, settings; SpeechRecognizer speech; TextToSpeech tts; boolean listening=false;
    android.content.SharedPreferences prefs;
    final int MIC_REQ=42;

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(0,3,6)); getWindow().setNavigationBarColor(Color.rgb(0,3,6));
        prefs=getSharedPreferences("mark",MODE_PRIVATE); buildUi();
        tts=new TextToSpeech(this, s -> { if(s==TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault()); });
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_REQ);
    }
    void buildUi(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(0,3,6));
        hud=new HudView(this); root.addView(hud,new FrameLayout.LayoutParams(-1,0){ {height=0;} });
        LinearLayout all=new LinearLayout(this); all.setOrientation(LinearLayout.VERTICAL); all.setPadding(18,14,18,14); root.addView(all,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); TextView title=label("◈  MARK LVII",18,Color.rgb(0,229,255)); top.addView(title,new LinearLayout.LayoutParams(0,55,1));
        settings=new Button(this); settings.setText("⚙"); settings.setTextColor(Color.rgb(0,229,255)); settings.setBackgroundColor(Color.TRANSPARENT); settings.setOnClickListener(v->showSettings()); top.addView(settings,new LinearLayout.LayoutParams(60,55)); all.addView(top);
        hud=new HudView(this); all.addView(hud,new LinearLayout.LayoutParams(-1,0,1));
        TextView status=label("●  ONLINE  •  VOICE READY",12,Color.rgb(0,190,210)); status.setGravity(Gravity.CENTER); all.addView(status,new LinearLayout.LayoutParams(-1,32));
        log=label("MARK LVII\nAwaiting command…",13,Color.rgb(155,215,225)); log.setGravity(Gravity.BOTTOM|Gravity.LEFT); log.setPadding(10,10,10,10); all.addView(log,new LinearLayout.LayoutParams(-1,120));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        input=new EditText(this); input.setSingleLine(true); input.setHint("Command Mark LVII…"); input.setHintTextColor(Color.rgb(70,105,115)); input.setTextColor(Color.WHITE); input.setBackgroundColor(Color.TRANSPARENT); row.addView(input,new LinearLayout.LayoutParams(0,60,1));
        mic=new Button(this); mic.setText("◉"); mic.setTextSize(22); mic.setTextColor(Color.rgb(0,229,255)); mic.setBackgroundColor(Color.TRANSPARENT); mic.setOnClickListener(v->toggleMic()); row.addView(mic,new LinearLayout.LayoutParams(60,60));
        send=new Button(this); send.setText("➤"); send.setTextColor(Color.rgb(0,229,255)); send.setBackgroundColor(Color.TRANSPARENT); send.setOnClickListener(v->sendText()); row.addView(send,new LinearLayout.LayoutParams(60,60)); all.addView(row);
        setContentView(root);
    }
    TextView label(String s,float size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);return t;}
    void sendText(){String s=input.getText().toString().trim();if(s.isEmpty())return; input.setText(""); append("YOU  ›  "+s); hud.thinking=true; hud.invalidate(); new Thread(()->callGemini(s)).start();}
    void append(String s){runOnUiThread(()->{String old=log.getText().toString(); String[] lines=(old+"\n"+s).split("\n"); StringBuilder x=new StringBuilder(); int start=Math.max(0,lines.length-9); for(int i=start;i<lines.length;i++){x.append(lines[i]).append('\n');} log.setText(x.toString());});}
    void toggleMic(){if(listening){stopMic();return;} if(speech==null) speech=SpeechRecognizer.createSpeechRecognizer(this); speech.setRecognitionListener(new RecognitionListener(){public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){listening=true;mic.setText("■");hud.listening=true;hud.invalidate();} public void onRmsChanged(float r){hud.amp=Math.min(1f,Math.abs(r)/10f);hud.invalidate();} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){listening=false;mic.setText("◉");hud.listening=false;hud.invalidate();} public void onError(int e){onEndOfSpeech();} public void onResults(Bundle b){ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty()){input.setText(a.get(0));sendText();}} public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){}}); Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);speech.startListening(i);}
    void stopMic(){if(speech!=null)speech.stopListening();listening=false;mic.setText("◉");hud.listening=false;hud.invalidate();}
    void callGemini(String prompt){String key=prefs.getString("api_key",""); if(key.isEmpty()){runOnUiThread(()->showSettings());hud.thinking=false;hud.invalidate();return;} try{
        URL u=new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="+URLEncoder.encode(key,"UTF-8")); HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");
        JSONObject body=new JSONObject(); JSONArray contents=new JSONArray(); JSONObject one=new JSONObject(); JSONArray parts=new JSONArray(); parts.put(new JSONObject().put("text","You are MARK LVII, a concise helpful personal AI assistant. Speak naturally.\nUser: "+prompt)); one.put("parts",parts); contents.put(one); body.put("contents",contents); OutputStream os=c.getOutputStream();os.write(body.toString().getBytes(StandardCharsets.UTF_8));os.close();
        InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream(); String res=new String(read(in),StandardCharsets.UTF_8); JSONObject j=new JSONObject(res); String out=j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text"); append("JARVIS  ›  "+out); speak(out);
    }catch(Exception e){append("SYSTEM  ›  "+e.getMessage());} finally {hud.thinking=false;hud.invalidate();}}
    byte[] read(InputStream in)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[4096];int n;while((n=in.read(z))!=-1)b.write(z,0,n);return b.toByteArray();}
    void speak(String s){runOnUiThread(()->{if(tts!=null){hud.speaking=true;hud.invalidate();tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"mark");new Handler().postDelayed(()->{hud.speaking=false;hud.invalidate();},Math.min(8000,Math.max(1200,s.length()*45)));}});}
    void showSettings(){final EditText e=new EditText(this);e.setHint("Paste Gemini API key");e.setText(prefs.getString("api_key",""));e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setInputType(129); LinearLayout box=new LinearLayout(this);box.setPadding(35,10,35,5);box.addView(e,new LinearLayout.LayoutParams(-1,60)); new AlertDialog.Builder(this).setTitle("MARK LVII • ENGINE").setMessage("The Android port uses your Gemini API key directly. Keep it private.").setView(box).setPositiveButton("SAVE",(d,w)->prefs.edit().putString("api_key",e.getText().toString().trim()).apply()).setNegativeButton("CANCEL",null).show();}
    @Override protected void onDestroy(){if(speech!=null)speech.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}

    class HudView extends View {Paint p=new Paint(3);float amp=0;boolean listening=false,thinking=false,speaking=false;float phase=0;
        HudView(Context c){super(c);p.setTypeface(Typeface.create("sans",Typeface.NORMAL));post(frame);}
        void frame(){phase+=0.045;invalidate();postDelayed(this::frame,33);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f-10;float r=Math.min(w,h)*.25f; p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.argb(70,0,229,255));c.drawCircle(cx,cy,r*1.55f,p);p.setColor(Color.argb(120,0,229,255));c.drawCircle(cx,cy,r*1.25f,p);p.setColor(Color.argb(190,0,229,255));c.drawCircle(cx,cy,r,p);
            for(int i=0;i<3;i++){float rr=r*(.75f+i*.18f)+(float)Math.sin(phase+i)*3;p.setColor(Color.argb(100-i*20,0,229,255));c.drawCircle(cx,cy,rr,p);} p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(35,0,229,255));c.drawCircle(cx,cy,r*.78f,p);p.setColor(Color.rgb(0,229,255));p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextSize(r*.25f);c.drawText("MARK",cx,cy+8,p);p.setTextSize(r*.08f);c.drawText(listening?"LISTENING":thinking?"THINKING":speaking?"SPEAKING":"STANDBY",cx,cy+r*.55f,p);
            p.setStrokeWidth(1);p.setColor(Color.argb(90,0,229,255));for(int i=0;i<48;i++){double a=(Math.PI*2*i/48)+phase*.2;float v=1+(float)Math.sin(i*.9+phase*5)*.08f+(listening?amp*.35f:0);float x1=cx+(float)Math.cos(a)*r*1.65f,y1=cy+(float)Math.sin(a)*r*1.65f,x2=cx+(float)Math.cos(a)*r*1.65f*v,y2=cy+(float)Math.sin(a)*r*1.65f*v;c.drawLine(x1,y1,x2,y2,p);}}
    }
}
