# Mark LVII – Selected Features Extract

This package contains **only the source files** related to the 5 features you requested from the original Mark LVII project.

**Important:**  
This is **not** a ready-to-run Android APK.  
It is a clean extraction of the relevant Python modules so you (or an AI / developer) can use them as reference or starting point to build a proper Android version.

---

## Selected Features

1. **Gemini API conversation**  
   - `core/gemini.py`          → Main Gemini one-shot + Live-related logic  
   - `core/cloud.py`           → Cloud / Gemini client helpers  
   - `core/llm_client.py`      → LLM client abstraction  
   - `providers/llm_openai.py` → OpenAI-compatible provider (can be adapted for Gemini)  
   - `providers/engine_pipeline.py`, `base.py`, `registry.py`, `schema.py`

2. **Real-time info + Internet search**  
   - `actions/web_search.py`   → Web search action

3. **Always listen (continuous listening / wake word / STT)**  
   - `core/stt.py`  
   - `core/wake_word.py`  
   - `core/audio_devices.py`  
   - `core/echo.py`            → Handles self-echo cancellation  
   - `providers/stt_whisper.py`  
   - `providers/audio.py`

4. **Device control (open apps, volume, brightness)**  
   - `actions/open_app.py`  
   - `actions/computer_settings.py`  → Volume, brightness, etc.  
   - `actions/computer_control.py`  
   - `actions/desktop.py`  
   - `core/appidentity.py`

5. **Memory (persistent memory across sessions)**  
   - `memory/memory_manager.py`  
   - `memory/config_manager.py`  
   - `memory/__init__.py`

---

## Supporting files included
- `core/lazyimport.py`, `core/outcome.py`, `core/confirm.py`, `core/platform_support.py`, `core/tts.py`, `core/prompt.txt`
- `providers/tts_system.py`
- `requirements.txt` (original – you will need to trim it heavily for Android)

---

## What you still need to do for Android

These files are written for **desktop Python** (Windows / macOS / Linux).  
To make a real Android app you must:

- Rewrite the UI and main loop in **Kotlin + Jetpack Compose** (or Flutter / React Native if preferred)
- Replace desktop audio / mic handling with Android `AudioRecord` / SpeechRecognizer or a proper STT library
- Replace volume/brightness/open-app with Android `AudioManager`, `Settings`, and `PackageManager` / Intents
- Store memory using Room / DataStore / SharedPreferences or a small local database
- Use the official Google AI / Gemini Android SDK (or Firebase AI Logic) instead of the Python Gemini client
- Handle Android permissions (RECORD_AUDIO, INTERNET, etc.) properly
- Background listening on Android is restricted – you will need a foreground service + careful battery handling

---

## Recommended next step

Take this extracted package + your 5 feature list and feed it to Google AI Studio (Android mode) or to a developer, asking it to build a clean native Android app that implements exactly these 5 capabilities, using modern Android best practices.

The original desktop code here serves as a high-quality reference for the logic, prompts, and behavior you want.
