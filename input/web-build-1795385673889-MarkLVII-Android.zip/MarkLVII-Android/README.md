# Mark LVII – Android

Native Android (Kotlin + Jetpack Compose) rewrite of your 5 selected features.

| Feature | Where |
|---|---|
| Gemini conversation (with tool calling) | `GeminiClient.kt`, `Agent.kt` |
| Real-time info + internet search | `WebSearch.kt` |
| Always listen + wake word + echo guard | `ListenService.kt`, `Speaker.kt` |
| Device control: open apps, volume, brightness | `DeviceControl.kt` |
| Persistent memory | `Prefs.kt`, Memory tab |

## Get the APK (no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab -> **Build APK** -> wait ~5 minutes.
3. Open the finished run -> download the **MarkLVII-debug-apk** artifact, unzip, and install `app-debug.apk` (allow "install unknown apps").

## Or build in Android Studio
Open this folder, let Gradle sync, then Build -> Build APK(s).

## First run
Settings tab -> paste a Gemini API key (free at aistudio.google.com/apikey) -> Save.
Tap the ear icon to start always-listen, then say "Jarvis, open YouTube".

## Notes
- Wake word detection uses Android's built-in speech recognizer (not the offline openWakeWord model from the PC version), so it needs internet and uses some battery.
- Brightness needs the "Modify system settings" permission; the app opens that screen on first use.
- `reference_python/` holds your original Python files for reference only; they are not part of the build.
