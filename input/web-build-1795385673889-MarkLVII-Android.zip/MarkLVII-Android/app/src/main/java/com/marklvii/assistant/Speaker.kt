package com.marklvii.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Text-to-speech wrapper (replaces core/tts.py). onDone lets the mic resume after speaking (echo guard). */
class Speaker(context: Context) {
    @Volatile var speaking = false
    var onDone: (() -> Unit)? = null
    private var ready = false
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) { tts.language = Locale.getDefault(); ready = true }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true }
            override fun onDone(id: String?) { speaking = false; onDone?.invoke() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { speaking = false; onDone?.invoke() }
        })
    }

    fun say(text: String) {
        if (!ready || text.isBlank()) { onDone?.invoke(); return }
        speaking = true
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mark")
    }
    fun stop() { tts.stop(); speaking = false }
    fun shutdown() { tts.shutdown() }
}
