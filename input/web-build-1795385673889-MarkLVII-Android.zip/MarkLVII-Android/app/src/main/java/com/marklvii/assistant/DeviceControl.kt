package com.marklvii.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings

/** Device control (replaces open_app.py / computer_settings.py, which used Windows APIs). */
object DeviceControl {

    fun openApp(c: Context, name: String): String {
        val pm = c.packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
        val q = name.trim().lowercase()
        // exact -> startsWith -> contains, like the desktop fuzzy matcher
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "No installed app matches \"$name\"."
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "Cannot launch ${hit.loadLabel(pm)}."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(intent)
        return "Opened ${hit.loadLabel(pm)}."
    }

    fun setVolume(c: Context, level: Int?, action: String?): String {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        when (action) {
            "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
            "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
            "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            "unmute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            else -> if (level != null) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (level.coerceIn(0, 100) * max / 100), 0)
            } else return "Give a level (0-100) or an action."
        }
        return "Volume now ${am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max}%."
    }

    fun setBrightness(c: Context, level: Int): String {
        if (!Settings.System.canWrite(c)) {
            val i = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            return "I need the 'Modify system settings' permission first. I opened that screen; enable it, then ask again."
        }
        val v = (level.coerceIn(0, 100) * 255 / 100)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
        return "Brightness set to ${level.coerceIn(0, 100)}%."
    }
}
