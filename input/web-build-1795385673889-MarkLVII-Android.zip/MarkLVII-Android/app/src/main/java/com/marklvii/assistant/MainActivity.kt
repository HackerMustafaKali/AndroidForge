package com.marklvii.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var speaker: Speaker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speaker = Speaker(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF4FC3F7), background = Color(0xFF0B0F14), surface = Color(0xFF141A22))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App(speaker) }
            }
        }
    }
    override fun onDestroy() { speaker.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(speaker: Speaker) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(ListenService.running) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) { ListenService.start(ctx); listening = true }
    }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) scope.launch { speaker.say(Agent.ask(ctx, t)) }
    }

    fun send(text: String) {
        if (text.isBlank() || Agent.busy) return
        input = ""
        scope.launch { speaker.say(Agent.ask(ctx, text)) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Mark LVII") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                actions = {
                    IconButton(onClick = {
                        if (listening) { ListenService.stop(ctx); listening = false }
                        else {
                            val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
                            if (need.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }) {
                                ListenService.start(ctx); listening = true
                            } else permLauncher.launch(need.toTypedArray())
                        }
                    }) {
                        Icon(if (listening) Icons.Default.Hearing else Icons.Default.HearingDisabled,
                            contentDescription = "Always listen",
                            tint = if (listening) Color(0xFF66BB6A) else Color.Gray)
                    }
                })
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Chat, null) }, label = { Text("Chat") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Memory, null) }, label = { Text("Memory") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ChatTab(input, { input = it }, ::send) {
                    voiceLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
                }
                1 -> MemoryTab()
                else -> SettingsTab()
            }
        }
    }
}

@Composable
fun ChatTab(input: String, onInput: (String) -> Unit, onSend: (String) -> Unit, onMic: () -> Unit) {
    val list = rememberLazyListState()
    val msgs = Agent.messages
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }
    Column(Modifier.fillMaxSize().imePadding()) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list,
            verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            if (msgs.isEmpty()) item {
                Text("Type, tap the mic, or turn on the ear icon and say your wake word.",
                    color = Color.Gray, modifier = Modifier.padding(16.dp))
            }
            items(msgs) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Surface(shape = RoundedCornerShape(16.dp),
                        color = if (m.fromUser) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surface) {
                        Text(m.text, Modifier.padding(12.dp).widthIn(max = 290.dp))
                    }
                }
            }
            if (Agent.busy) item { Text("Thinking…", color = Color.Gray) }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, onInput, Modifier.weight(1f), placeholder = { Text("Ask anything") }, maxLines = 4)
            IconButton(onMic) { Icon(Icons.Default.Mic, "Speak") }
            IconButton({ onSend(input) }) { Icon(Icons.Default.Send, "Send") }
        }
    }
}

@Composable
fun MemoryTab() {
    val ctx = LocalContext.current
    var mem by remember { mutableStateOf(Prefs.memory(ctx)) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Saved memory", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton({ mem = Prefs.memory(ctx) }) { Icon(Icons.Default.Refresh, "Refresh") }
            TextButton({ Prefs.clearMemory(ctx); mem = emptyMap() }) { Text("Clear all") }
        }
        if (mem.isEmpty()) Text("Nothing yet. Tell me things like \"remember my name is Sam\".", color = Color.Gray)
        LazyColumn {
            items(mem.entries.toList()) { e ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(e.key, color = MaterialTheme.colorScheme.primary)
                        Text(e.value)
                    }
                    IconButton({ Prefs.forget(ctx, e.key); mem = Prefs.memory(ctx) }) { Icon(Icons.Default.Delete, "Delete") }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun SettingsTab() {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.apiKey(ctx)) }
    var model by remember { mutableStateOf(Prefs.model(ctx)) }
    var wake by remember { mutableStateOf(Prefs.wakeWord(ctx)) }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(key, { key = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true)
        OutlinedTextField(model, { model = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Gemini model") }, singleLine = true)
        OutlinedTextField(wake, { wake = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Wake word") }, singleLine = true)
        Button({
            Prefs.setApiKey(ctx, key); Prefs.setModel(ctx, model); Prefs.setWakeWord(ctx, wake); saved = true
            if (ListenService.running) { ListenService.stop(ctx); ListenService.start(ctx) }
        }) { Text("Save") }
        if (saved) Text("Saved.", color = Color(0xFF66BB6A))
        Text("Get a free key at aistudio.google.com/apikey. For brightness control, Android will ask you to allow " +
            "\"Modify system settings\" the first time.", color = Color.Gray)
        TextButton({ Agent.reset() }) { Text("Clear chat") }
    }
}
