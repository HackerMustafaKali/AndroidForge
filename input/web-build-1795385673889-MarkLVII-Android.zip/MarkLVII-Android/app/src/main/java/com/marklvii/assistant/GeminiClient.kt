package com.marklvii.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Minimal Gemini REST client (replaces core/gemini.py + google-genai). */
object GeminiClient {
    fun generate(apiKey: String, model: String, system: String, contents: JSONArray, tools: JSONArray): JSONObject {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("tools", tools)
        val con = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = con.responseCode
        val text = (if (code in 200..299) con.inputStream else con.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrDefault(text)
            throw RuntimeException("Gemini error $code: $msg")
        }
        return JSONObject(text)
    }
}
