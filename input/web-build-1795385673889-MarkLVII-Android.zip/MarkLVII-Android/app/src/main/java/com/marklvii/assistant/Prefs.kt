package com.marklvii.assistant

import android.content.Context
import org.json.JSONObject

/** Settings + persistent memory (port of memory/config_manager.py and memory_manager.py). */
object Prefs {
    private const val FILE = "mark_lvii"
    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun apiKey(c: Context) = sp(c).getString("api_key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("api_key", v.trim()).apply()

    fun model(c: Context) = sp(c).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim()).apply()

    fun wakeWord(c: Context) = sp(c).getString("wake", "jarvis") ?: "jarvis"
    fun setWakeWord(c: Context, v: String) = sp(c).edit().putString("wake", v.trim().lowercase()).apply()

    fun assistantName(c: Context) = sp(c).getString("name", "Jarvis") ?: "Jarvis"

    // ---- Memory: key -> value facts that survive restarts ----
    fun memory(c: Context): Map<String, String> {
        val o = JSONObject(sp(c).getString("memory", "{}") ?: "{}")
        return o.keys().asSequence().associateWith { o.getString(it) }
    }
    fun remember(c: Context, key: String, value: String) {
        val o = JSONObject(sp(c).getString("memory", "{}") ?: "{}")
        o.put(key.trim().lowercase(), value.trim())
        sp(c).edit().putString("memory", o.toString()).apply()
    }
    fun forget(c: Context, key: String): Boolean {
        val o = JSONObject(sp(c).getString("memory", "{}") ?: "{}")
        val had = o.has(key.trim().lowercase())
        o.remove(key.trim().lowercase())
        sp(c).edit().putString("memory", o.toString()).apply()
        return had
    }
    fun clearMemory(c: Context) = sp(c).edit().putString("memory", "{}").apply()
}
