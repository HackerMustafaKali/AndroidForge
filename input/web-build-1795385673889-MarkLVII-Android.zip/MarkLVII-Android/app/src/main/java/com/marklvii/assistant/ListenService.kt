package com.marklvii.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Always-listen foreground service (replaces stt.py / wake_word.py / echo.py).
 * Loops Android's SpeechRecognizer. Hearing the wake word + a command runs it; saying only the
 * wake word opens a short "conversation window" so the next sentence needs no wake word.
 * The mic is paused while the assistant speaks so it never hears itself.
 */
class ListenService : Service() {
    companion object {
        @Volatile var running = false
        const val CH = "mark_listen"
        fun start(c: Context) {
            val i = Intent(c, ListenService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
        fun stop(c: Context) { c.stopService(Intent(c, ListenService::class.java)) }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var recognizer: SpeechRecognizer? = null
    private lateinit var speaker: Speaker
    private var awakeUntil = 0L
    private var paused = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(CH, "Listening", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, CH)
            .setContentTitle("Mark LVII is listening")
            .setContentText("Say \"${Prefs.wakeWord(this)}\" to talk")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        speaker = Speaker(this)
        speaker.onDone = { main.postDelayed({ paused = false; listen() }, 400) }
        listen()
    }

    private fun listen() {
        if (!running || paused) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) handle(t)
                    restartSoon()
                }
                override fun onError(e: Int) {
                    // no-match / timeout are normal in continuous listening; back off on real errors
                    restartSoon(if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 300 else 2000)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            })
        }
    }

    private fun restartSoon(delay: Long = 250) {
        if (running && !paused) main.postDelayed({ listen() }, delay)
    }

    private fun handle(heard: String) {
        val wake = Prefs.wakeWord(this)
        val lower = heard.lowercase()
        val now = System.currentTimeMillis()
        val idx = lower.indexOf(wake)
        val command: String = when {
            idx >= 0 -> {
                val rest = heard.substring(idx + wake.length).trim(' ', ',', '.', '!', '?')
                if (rest.isEmpty()) { awakeUntil = now + 8000 }
                rest
            }
            now < awakeUntil -> heard
            else -> return   // not addressed to us
        }
        if (command.isBlank()) return
        awakeUntil = now + 8000
        paused = true
        scope.launch {
            val reply = Agent.ask(applicationContext, command)
            speaker.say(reply)
        }
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        speaker.shutdown()
        scope.cancel()
        super.onDestroy()
    }
}
