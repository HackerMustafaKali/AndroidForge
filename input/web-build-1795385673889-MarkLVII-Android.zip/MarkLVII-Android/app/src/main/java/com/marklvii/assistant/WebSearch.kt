package com.marklvii.assistant

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

/** Real-time internet search (port of actions/web_search.py, DuckDuckGo HTML, no API key). */
object WebSearch {
    fun search(query: String, max: Int = 6): String {
        val q = URLEncoder.encode(query, "UTF-8")
        val con = (URL("https://html.duckduckgo.com/html/?q=$q").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 20000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        }
        val html = con.inputStream.bufferedReader().use { it.readText() }
        val link = Regex("""class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
        val snip = Regex("""class="result__snippet"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
        val links = link.findAll(html).toList()
        val snips = snip.findAll(html).toList()
        if (links.isEmpty()) return "No results found."
        val sb = StringBuilder()
        for (i in 0 until minOf(max, links.size)) {
            var href = links[i].groupValues[1]
            Regex("uddg=([^&]+)").find(href)?.let { href = URLDecoder.decode(it.groupValues[1], "UTF-8") }
            sb.append("${i + 1}. ${clean(links[i].groupValues[2])}\n   $href\n")
            if (i < snips.size) sb.append("   ${clean(snips[i].groupValues[1])}\n")
        }
        return sb.toString()
    }

    private fun clean(s: String) = s.replace(Regex("<[^>]+>"), "")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").trim()
}
