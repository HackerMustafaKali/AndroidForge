package com.marklvii.assistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class ChatMsg(val fromUser: Boolean, val text: String)

/** Conversation + tool-calling loop (port of the Gemini conversation logic). */
object Agent {
    val messages = mutableStateListOf<ChatMsg>()
    var busy by mutableStateOf(false)

    private val history = JSONArray()   // raw Gemini contents, kept verbatim

    fun reset() { messages.clear(); while (history.length() > 0) history.remove(0) }

    private fun systemPrompt(c: Context): String {
        val mem = Prefs.memory(c)
        val memText = if (mem.isEmpty()) "(nothing yet)" else mem.entries.joinToString("\n") { "- ${it.key}: ${it.value}" }
        return """
You are ${Prefs.assistantName(c)}, a voice assistant running natively on the user's Android phone.
Speak briefly and concretely; your replies are read aloud. Lead with the answer. No markdown, no emojis.
If a request is within your tools, CALL the tool instead of describing it.
Use web_search for anything current: news, weather, scores, prices, recent facts.
Use remember when the user tells you a lasting fact or preference; use forget when asked to.
You can: open installed apps, set volume, set brightness, search the web, remember facts.
You cannot: control other apps' contents, read the screen, place calls or send messages.
Say so plainly when asked for something outside that.

What you remember about the user:
$memText
""".trim()
    }

    private fun tools(): JSONArray {
        fun fn(name: String, desc: String, props: JSONObject, req: List<String>) = JSONObject()
            .put("name", name).put("description", desc)
            .put("parameters", JSONObject().put("type", "OBJECT").put("properties", props)
                .put("required", JSONArray(req)))
        fun str(d: String) = JSONObject().put("type", "STRING").put("description", d)
        fun int(d: String) = JSONObject().put("type", "INTEGER").put("description", d)
        val decls = JSONArray()
            .put(fn("web_search", "Search the internet for current information.",
                JSONObject().put("query", str("search query")), listOf("query")))
            .put(fn("open_app", "Open an installed app by its name.",
                JSONObject().put("name", str("app name, e.g. YouTube")), listOf("name")))
            .put(fn("set_volume", "Change media volume. Use level (0-100) or action up/down/mute/unmute.",
                JSONObject().put("level", int("0-100")).put("action", str("up, down, mute or unmute")), listOf()))
            .put(fn("set_brightness", "Set screen brightness 0-100.",
                JSONObject().put("level", int("0-100")), listOf("level")))
            .put(fn("remember", "Save a lasting fact about the user.",
                JSONObject().put("key", str("short label")).put("value", str("the fact")), listOf("key", "value")))
            .put(fn("forget", "Delete a remembered fact.",
                JSONObject().put("key", str("label to delete")), listOf("key")))
        return JSONArray().put(JSONObject().put("function_declarations", decls))
    }

    private fun runTool(c: Context, name: String, a: JSONObject): String = try {
        when (name) {
            "web_search" -> WebSearch.search(a.getString("query"))
            "open_app" -> DeviceControl.openApp(c, a.getString("name"))
            "set_volume" -> DeviceControl.setVolume(c,
                if (a.has("level")) a.getInt("level") else null,
                if (a.has("action")) a.getString("action") else null)
            "set_brightness" -> DeviceControl.setBrightness(c, a.getInt("level"))
            "remember" -> { Prefs.remember(c, a.getString("key"), a.getString("value")); "Saved." }
            "forget" -> if (Prefs.forget(c, a.getString("key"))) "Forgotten." else "Nothing stored under that name."
            else -> "Unknown tool $name."
        }
    } catch (e: Exception) { "Tool error: ${e.message}" }

    /** Sends a user message, runs tool calls, returns the spoken/displayed reply. */
    suspend fun ask(c: Context, userText: String): String = withContext(Dispatchers.IO) {
        val app = c.applicationContext
        val key = Prefs.apiKey(app)
        if (key.isBlank()) return@withContext "Please add your Gemini API key in Settings first."
        messages.add(ChatMsg(true, userText))
        busy = true
        try {
            history.put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText))))
            var reply = ""
            for (step in 0 until 6) {
                val res = GeminiClient.generate(key, Prefs.model(app), systemPrompt(app), history, tools())
                val content = res.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                if (content == null) { reply = "I got an empty response."; break }
                history.put(content)
                val parts = content.optJSONArray("parts") ?: JSONArray()
                val calls = (0 until parts.length()).map { parts.getJSONObject(it) }.filter { it.has("functionCall") }
                if (calls.isEmpty()) {
                    reply = (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").ifBlank { null } }
                        .joinToString(" ").trim()
                    break
                }
                val responses = JSONArray()
                for (p in calls) {
                    val fc = p.getJSONObject("functionCall")
                    val out = runTool(app, fc.getString("name"), fc.optJSONObject("args") ?: JSONObject())
                    responses.put(JSONObject().put("functionResponse", JSONObject()
                        .put("name", fc.getString("name"))
                        .put("response", JSONObject().put("result", out))))
                }
                history.put(JSONObject().put("role", "user").put("parts", responses))
            }
            if (reply.isBlank()) reply = "Done."
            messages.add(ChatMsg(false, reply))
            reply
        } catch (e: Exception) {
            val m = "Sorry, ${e.message}"
            messages.add(ChatMsg(false, m)); m
        } finally { busy = false }
    }
}
